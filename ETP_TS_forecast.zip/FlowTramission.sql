DROP PROCEDURE IF EXISTS Destruction;
DROP PROCEDURE IF EXISTS Creation;

DELIMITER //
CREATE PROCEDURE Destruction()
BEGIN
	SET @@GLOBAL.event_scheduler = ON;
	DROP EVENT IF EXISTS iterator;
	DROP TABLE IF EXISTS id_incrementor;
	DROP TABLE IF EXISTS hourly_in_collect;
	DROP TABLE IF EXISTS test_table;
	DROP TRIGGER IF EXISTS trans_trig;
END//
DELIMITER ;

DELIMITER %%
CREATE PROCEDURE Creation()
BEGIN
	# the following sql script functions as a simulation of real-time data generation
	# data is transmitted from a flow meter with a transimtter actuated hourly (here the flow meter is indicated as hourly flow in)
	# data is received by a table in a schema of a DBMS. (here the table is indicated as hourly in collect).
	# hourly_in_collect is updated every @timer seconds/minutes. This occurs from CURRENT_TIMESTAMP + @timestart seconds/minutes until @timeout seconds/minutes
	# @timer,@timestart and @timeout are 10s,5s and 86400 seconds respectively. However, they can be modified by changing the values below
	# @simvar is the relative time at which simulation and visualization begins. 
    
	SET @timer=10; #seconds
	SET @timestart=5; #seconds
	SET @timeout=86400; #seconds
    SET @simvar = (SELECT FLOOR( RAND()*(60000-50000))+50000);

	# an event is created to implement the transfer, a table id_incrementor is created. 
	# a second table test_table is created to store tail values in the table ranging from value 50,000 to 80,000.
	# an event ("iterator") applied to the id_incrementor table. This event updates the second column of the table,thereby increasing the auto-incremental primary key by one on every iteration.
	# a trigger ("trans_trigger) is connected to the id-incrementor. this trigger updates the values in hourly_collect_in using the joint between the primary key of "id.incrementor" and "test_table".
	# RStudio's ODBC API can now query test_table.

	CREATE TABLE id_incrementor (id INT PRIMARY KEY AUTO_INCREMENT NOT NULL, placeholder INT DEFAULT NULL);
	CREATE TABLE test_table AS (SELECT * FROM hourly_flow_in WHERE ref_time > @simvar);
	ALTER TABLE test_table ADD PK2 INT PRIMARY KEY AUTO_INCREMENT NOT NULL;
    ALTER TABLE test_table AUTO_INCREMENT 2000;
	CREATE TABLE hourly_in_collect (start_stamp VARCHAR(40), end_stamp VARCHAR(40), ref_time INT,total_flow VARCHAR(40));
    END %% 
    DELIMITER ;